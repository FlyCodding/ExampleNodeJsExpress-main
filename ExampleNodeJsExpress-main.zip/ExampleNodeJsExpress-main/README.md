# ExampleNodeJsExpress
A simple example using Express js for Rest Api
